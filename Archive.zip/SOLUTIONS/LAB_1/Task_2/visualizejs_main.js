visualize({
    auth: {
        name: "jasperadmin",
        password: "jasperadmin",
        organization: "organization_1"
    }
}, function (v) {
    /*HERE WE'LL ADD OR VISUALIZE.JS CALLS*/
    alert('Visualize.js is ready')
 
});